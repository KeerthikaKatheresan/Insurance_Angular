import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-about',
  standalone: true,
  templateUrl: './about.html',
  styleUrls: ['./about.css'],
  imports: [CommonModule,FormsModule,RouterModule],
})
export class AboutComponent {

  appName: string = 'Raindrop Insurance Service Application';

  developer = {
    name: 'Keerthika Kadhiresan',
    role: 'Frontend Developer',
    tech: 'Angular'
  };

  features: string[] = [
    'View and compare insurance plans',
    'Calculate premium easily',
    'Secure online payment',
    'Instant booking confirmation',
    'User-friendly interface'
  ];
}
