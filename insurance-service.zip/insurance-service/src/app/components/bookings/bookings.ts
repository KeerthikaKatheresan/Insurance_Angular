import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { InsuranceService } from '../../services/insurance';

@Component({
  selector: 'app-bookings',
  imports: [CommonModule],
  templateUrl: './bookings.html',
  styleUrl: './bookings.css',
})
export class Bookings implements OnInit {
  email!: string;
  bookings: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private insuranceService: InsuranceService
  ) {}

  ngOnInit(): void {
    this.email = this.route.snapshot.queryParamMap.get('email')!;

    this.insuranceService
      .getBookingsByEmail(this.email)
      .subscribe((data) => (this.bookings = data));
  }
}
