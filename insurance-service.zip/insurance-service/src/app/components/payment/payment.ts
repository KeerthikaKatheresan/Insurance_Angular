import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InsuranceService } from '../../services/insurance';
import { Booking } from '../../models/booking.model';
import { Plan } from '../../models/plan.model';
import { UserService } from '../../services/user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.html',
  styleUrls: ['./payment.css'],
  imports: [FormsModule, CommonModule],
})
export class PaymentComponent implements OnInit {
  plan!: Plan;
  name!: string;
  email!: string;
  city!: string;
  age!: number;

  cardNumber: string = '';
  paymentMode: string = '';
  paymentFreq: string = '';

  submitted = false;

  constructor(
    private router: Router,
    private insuranceService: InsuranceService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    // fetch user details from service
    const user = this.userService.getUserDetails();
    this.name = user.name;
    this.email = user.email;
    this.city = user.city;
    this.age = user.age;

    // fetch selected plan from service
    this.plan = this.insuranceService.getSelectedPlan();
  }

  submitPayment() {
    this.submitted = true;

    if (!this.cardNumber || this.cardNumber.length < 12) {
      alert('Enter valid card number');
      return;
    }

    if (!this.paymentMode || !this.paymentFreq) {
      alert('Enter payment mode and frequency');
      return;
    }

    const booking: Booking = {
      name: this.name,
      email: this.email,
      city: this.city,
      age: this.age,
      cardNumber: this.cardNumber,
      planId: this.plan.planId,
      planName: this.plan.planName,
      premiumAmt: this.plan.baseAmt,
      paymentMode: this.paymentMode,
      paymentFreq: this.paymentFreq,
      bookingDate: new Date().toISOString(),
    };

    // Save booking and redirect
    this.insuranceService.bookPlan(booking).subscribe({
      next: () => {
        console.log('Booking successful');
        this.router.navigate(['/bookings'], {
          queryParams: { email: this.email },
        });
      },
      error: (err) => {
        console.error(err);
        alert('Payment failed. Try again.');
      },
    });
  }
}
