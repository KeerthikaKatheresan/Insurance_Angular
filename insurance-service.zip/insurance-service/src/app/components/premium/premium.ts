import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UserDetails } from '../../models/user-details.model';
import { Plan } from '../../models/plan.model';
import { UserService } from '../../services/user.service';
import { InsuranceService } from '../../services/insurance';
import { Router } from '@angular/router';

@Component({
  selector: 'app-premium',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './premium.html',
  styleUrls: ['./premium.css'],
})
export class PremiumComponent implements OnInit {
  user!: UserDetails;
  plan!: Plan;
  finalPremium = 0;

  constructor(
    private userService: UserService,
    private insuranceService: InsuranceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.user = this.userService.getUserDetails();
    this.plan = this.insuranceService.getSelectedPlan();

    this.calculatePremium();
  }

  calculatePremium() {
    let premium = this.plan.baseAmt;

    if (this.user.age > 45) premium += 2000;
    if (this.user.salary > 1000000) premium += 1500;
    if (this.user.healthIssue) premium += 3000;

    this.finalPremium = premium;
  }

  buyNow() {
    this.router.navigate(['/payment', this.plan.planId]);
  }
}
