export interface Booking {
  id?: string;
  name: string;
  email: string;
  city: string;
  age: number;
  cardNumber: string;

  planId: number;
  planName: string;
  premiumAmt: number;

  paymentMode: string;
  paymentFreq: string;
  bookingDate: string;
}
